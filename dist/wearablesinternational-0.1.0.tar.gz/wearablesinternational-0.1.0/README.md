# wearablesinternational

Pre-process, artifact detection, and feature eaxtraction for Empatica EmbracePlus https://www.empatica.com/embraceplus/ and Nowatch https://nowatch.com/

## Installation

```bash
$ pip install wearablesinternational
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`wearablesinternational` was created by Peter de Looff and Selin Acan. It is licensed under the terms of the MIT license.


